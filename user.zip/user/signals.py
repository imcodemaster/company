@receiver(post_save, sender = User)
# user profile creation 
def create_user_profile(sender, instance,created , **kwargs):
	print('*****', created)

	if instance.is_salesexecutive: 
		SalesexecutiveProfile.objects.get_or_create(user = instance)

	elif instance.is_abm:
		ABMProfile.objects.get_or_create(user = instance)

	elif instance.is_zbm:
		ZBMProfile.objects.get_or_create(user = instance)

	elif instance.is_rbm:
		RBMProfile.objects.get_or_create(user = instance)

	else:
		AdminProfile.objects.get_or_create(user = instance)


@receiver(post_save, sender = User)
# user profile save
def save_user_profile(sender, instance, **kwargs):
	print('-----')

	if instance.is_salesexecutive: 
		instance.Salesexecutive_Profile.save()

	elif instance.is_abm:
		instance.ABM_Profile.save()

	elif instance.is_zbm:
		instance.ZBM_Profile.save()

	elif instance.is_rbm:
		instance.RBM_Profile.save()

	else:
		instance.Admin_Profile.save()



