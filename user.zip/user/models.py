from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.

class User(AbstractUser):
	is_salesexecutive = models.BooleanField(default = True)
	is_abm = models.BooleanField(default = True)
	is_zbm = models.BooleanField(default = True)
	is_rbm = models.BooleanField(default = True)
	is_admin = models.BooleanField(default = True)

# sales executive profile models

class SalesexecutiveProfile(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , null = True, related_name = 'Salesexecutive_Profile')
	bio = models.CharField(max_length = 30 , blank = True)
	location = models.CharField(max_length = 30 , blank = True)

# ABM Profile profile models
class ABMProfile(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , null = True, related_name = 'ABM_Profile')
	bio = models.CharField(max_length = 30 , blank = True)
	company = models.CharField(max_length = 30 , blank = True)
	location = models.CharField(max_length = 30 , blank = True)

# ZBM profile models
class ZBMProfile(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , null = True, related_name = 'ZBM_Profile')
	bio = models.CharField(max_length = 30 , blank = True)
	website = models.CharField(max_length = 30 , blank = True)
	location = models.CharField(max_length = 30 , blank = True)

# RBM profile models
class RBMProfile(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , null = True, related_name = 'RBM_Profile')
	bio = models.CharField(max_length = 30 , blank = True)
	region_name = models.CharField(max_length = 30 , blank = True)
	location = models.CharField(max_length = 30 , blank = True)

# Profile profile models
class AdminProfile(models.Model):
	user = models.OneToOneField(User , on_delete = models.CASCADE , null = True, related_name = 'Admin_Profile')
	bio = models.CharField(max_length = 30 , blank = True)
	my_company = models.CharField(max_length = 30 , blank = True)
	location = models.CharField(max_length = 30 , blank = True)