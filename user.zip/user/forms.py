# user form creation 
class UserForm(forms.ModelForm):
	class Meta : 
		model  = User
		fields = ('first_name', 'last_name', 'email')


# sales executive profile form creation 

class SalesexecutiveProfileForm(forms.ModelForm):
	class Meta : 
		model  = SalesexecutiveProfile
		fields = ('location' , 'bio')

# ABM profile form creation 


class ABMProfileForm(forms.ModelForm):
	class Meta : 
		model  = ABMProfile
		fields = ('bio', 'location', 'company')

# ZBM profile form creation 


class ZBMProfileForm(forms.ModelForm):
	class Meta : 
		model  = ZBMProfile
		fields = ('bio', 'location', 'website')

# RBM profile form creation 


class RBMProfileForm(forms.ModelForm):
	class Meta : 
		model  = RBMProfile
		fields = ('bio', 'location', 'region_name')


# Admin profile form creation 


class AdminProfileForm(forms.ModelForm):
	class Meta : 
		model  = AdminProfile
		fields = ('bio', 'location', 'my_company')

