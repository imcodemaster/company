from django.shortcuts import render

# Create your views here.

# sales executive profile view  

def salesexecutive_profile_view(request):
	if request.method == 'POST':
		user_form = user_form(request.POST, prefix = 'UF')
					profile_form = SalesexecutiveProfileForm(request.POST, prefix = 'SPF')

	if user_form.is_valid() and profile_form.is_valid():
		user = user_form.save(commit = False)
		user.save()

		user.Salesexecutive_Profile.bio = profile_form.cleaned_data.get('bio')
		user.Salesexecutive_Profile.location = profile_form.cleaned_data.get('location')
		user.Salesexecutive_Profile.save()

	else:
		user_form = UserForm(prefix = 'UF')
		profile_form = SalesexecutiveProfileForm(prefix = 'SPF')

# template se_profile inside pofile folder  
	return render(request, 'profile/se_profile.html',{
		'user_form' : user_form,
		'profile_form' : profile_form,
		})

# ABM Profile View

def ABM_profile_view(request):
	if request.method == 'POST':
		user_form = user_form(request.POST, prefix = 'UF')
					profile_form = ABMProfileForm(request.POST, prefix = 'ABMPF')

	if user_form.is_valid() and profile_form.is_valid():
		user = user_form.save(commit = False)
		user.save()

		user.ABMProfile.bio = profile_form.cleaned_data.get('bio')
		user.ABMProfile.company = profile_form.cleaned_data.get('company')
		user.ABMProfile.location = profile_form.cleaned_data.get('location')
		user.ABMProfile.save()

	else:
		user_form = UserForm(prefix = 'UF')
		profile_form = ABMProfileForm(prefix = 'ABMPF')

	return render(request, 'profile/abm_profile.html',{
		'user_form' : user_form,
		'profile_form' : profile_form,
		})


# ZBM profile view

def ZBM_profile_view(request):
	if request.method == 'POST':
		user_form = user_form(request.POST, prefix = 'UF')
					profile_form = ZBMProfileForm(request.POST, prefix = 'ZBMPF')

	if user_form.is_valid() and profile_form.is_valid():
		user = user_form.save(commit = False)
		user.save()

		user.ZBMProfile.bio = profile_form.cleaned_data.get('bio')
		user.ZBMProfile.website = profile_form.cleaned_data.get('website')
		user.ZBMProfile.location = profile_form.cleaned_data.get('location')
		user.ZBMProfile.save()

	else:
		user_form = UserForm(prefix = 'UF')
		profile_form = ZBMProfileForm(prefix = 'ZBMPF')

	return render(request, 'profile/zbm_profile.html',{
		'user_form' : user_form,
		'profile_form' : profile_form,
		})

#RBM profile view

def RBM_profile_view(request):
	if request.method == 'POST':
		user_form = user_form(request.POST, prefix = 'UF')
					profile_form = RBMProfileForm(request.POST, prefix = 'RBMPF')

	if user_form.is_valid() and profile_form.is_valid():
		user = user_form.save(commit = False)
		user.save()

		user.RBMProfile.bio = profile_form.cleaned_data.get('bio')
		user.RBMProfile.region_name = profile_form.cleaned_data.get('region_name')
		user.RBMProfile.location = profile_form.cleaned_data.get('location')
		user.RBMProfile.save()

	else:
		user_form = UserForm(prefix = 'UF')
		profile_form = RBMProfileForm(prefix = 'RBMPF')

	return render(request, 'profile/rbm_profile.html',{
		'user_form' : user_form,
		'profile_form' : profile_form,
		})


#admin profile view

def Admin_profile_view(request):
	if request.method == 'POST':
		user_form = user_form(request.POST, prefix = 'UF')
					profile_form = AdminProfileForm(request.POST, prefix = 'AdminPF')

	if user_form.is_valid() and profile_form.is_valid():
		user = user_form.save(commit = False)
		user.save()

		user.AdminProfile.bio = profile_form.cleaned_data.get('bio')
		user.AdminProfile.my_company = profile_form.cleaned_data.get('my_company')
		user.AdminProfile.location = profile_form.cleaned_data.get('location')
		user.AdminProfile.save()

	else:
		user_form = UserForm(prefix = 'UF')
		profile_form = AdminProfileForm(prefix = 'AdminPF')

	return render(request, 'profile/admin_profile.html',{
		'user_form' : user_form,
		'profile_form' : profile_form,
		})


# need to make urls.py for user app